package com.proyecto.quickorder;

import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.proyecto.quickorder.database.PedidoDataSource;
import com.proyecto.quickorder.library.Pedido;


public class AgregarPedido extends AppCompatActivity {

    public static final String LOGTAG = "AgregarPedido";
    PedidoDataSource dataSource;
    EditText etNombre, etOrigen, etDestino, etEstado, etPrecio;
    String nombre, origen, destino, estado, precio;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agregar_pedido);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        dataSource = new PedidoDataSource(this);

        etNombre = findViewById(R.id.etNombre);
        etOrigen = findViewById(R.id.etOrigen);
        etDestino = findViewById(R.id.etDestino);
        etEstado = findViewById(R.id.etEstado);
        etPrecio = findViewById(R.id.etPrecio);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_agregar_pedido, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        int id = item.getItemId();
        switch (id){
            case android.R.id.home:
                finish();
                break;
            case R.id.action_guardar_pedido:
                dataSource.openDB();
                guardarPedido();
                dataSource.closeDB();

                break;
                default:
                    break;
        }
        return super.onOptionsItemSelected(item);

    }

    public void guardarPedido() {

        nombre = etNombre.getText().toString();
        origen = etOrigen.getText().toString();
        destino = etDestino.getText().toString();
        estado = etEstado.getText().toString();
        precio = etPrecio.getText().toString();

        if (crearPedido() != -1) {
            Toast.makeText(this, "Pedido guardado", Toast.LENGTH_SHORT).show();
            setResult(1);
            finish();
        }
    }

        public long crearPedido(){
            Pedido pedido = new Pedido();
            pedido.setNombre(nombre);
            pedido.setOrigen(origen);
            pedido.setDestino(destino);
            pedido.setEstado(estado);
            pedido.setPrecio(precio);

            pedido = dataSource.insertarPedido(pedido);
            Log.i(LOGTAG, "Se insertó pedido con id: "+pedido.getId());

            return pedido.getId();
        }

}
