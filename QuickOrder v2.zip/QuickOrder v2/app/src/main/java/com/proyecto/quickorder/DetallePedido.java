package com.proyecto.quickorder;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.TextView;

public class DetallePedido extends AppCompatActivity {

    TextView tvNombre, tvOrigen, tvDestino, tvEstado, tvPrecio;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalle_pedido);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        tvNombre = findViewById(R.id.tvNombre);
        tvOrigen = findViewById(R.id.tvOrigen);
        tvDestino = findViewById(R.id.tvDestino);
        tvEstado = findViewById(R.id.tvEstado);
        tvPrecio = findViewById(R.id.tvPrecio);

        Intent intent = getIntent();
        String nombre = intent.getStringExtra("nombre");
        String origen = intent.getStringExtra("Origen");
        String destino = intent.getStringExtra("Destino");
        String estado = intent.getStringExtra("Estado");
        String precio = intent.getStringExtra("precio");

        setTitle(nombre);

        tvNombre.setText(nombre);
        tvOrigen.setText(origen);
        tvDestino.setText(destino);
        tvEstado.setText(estado);
        tvPrecio.setText(precio);

    }

    public boolean onOptionsItemSelected(MenuItem item){
        int id = item.getItemId();

        switch (id){
            case android.R.id.home:
                finish();
            break;
            default:
                break;
        }

        return super.onOptionsItemSelected(item);
    }
}
