package com.proyecto.quickorder;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Login extends AppCompatActivity {

    EditText Txtuser, Txtpassword;

    Button btn_ING;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        Txtuser = (EditText)findViewById(R.id.ET_User);
        Txtpassword = (EditText)findViewById(R.id.ET_Password);

        btn_ING = (Button)findViewById(R.id.btn_Ingresar);

        btn_ING.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                String V_user = Txtuser.getText().toString();
                String V_password = Txtpassword.getText().toString();

                if (V_user.equals("Admin") && V_password.equals("Admin"))
                {

                    Intent intent = new Intent(getApplicationContext(),MainActivity.class);
                   startActivity(intent);
                    Toast.makeText(getApplicationContext(),"Bienvenid@!",Toast.LENGTH_SHORT).show();
                }

                else

                    {

                        Toast.makeText(getApplicationContext(),"Usuario o Password Erronea", Toast.LENGTH_SHORT).show();
                    }



            }
        });
    }
}
