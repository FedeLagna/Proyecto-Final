package com.proyecto.quickorder;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.proyecto.quickorder.database.PedidoDataSource;
import com.proyecto.quickorder.library.Pedido;
import com.proyecto.quickorder.library.PedidoAdapter;

import java.util.List;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemClickListener{

    public static final int CODE_AGREGAR_PEDIDO = 101;
    ListView lvPedidos;
    List<Pedido> pedidos;

    PedidoDataSource dataSource;
    PedidoAdapter adapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        lvPedidos = findViewById(R.id.lvPedidos);

        dataSource= new PedidoDataSource(this);

        actualizarLista();
        lvPedidos.setOnItemClickListener(this);
    }

    public void actualizarLista() {
        dataSource.openDB();
        pedidos = dataSource.obtenerPedido();
        dataSource.closeDB();

        adapter = new PedidoAdapter(this, R.layout.pedido_item,pedidos);
        lvPedidos.setAdapter(adapter);
    }

    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();
        switch (id) {
            case R.id.action_guardar_pedido:
                Intent intent = new Intent(this, AgregarPedido.class);
                startActivityForResult(intent, CODE_AGREGAR_PEDIDO);
                break;
            default:
                break;
        }
        return super.onOptionsItemSelected(item);
    }
    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

        Pedido pedido = pedidos.get(i);
        String nombre = pedido.getNombre();

        Intent intent = new Intent(this, DetallePedido.class);
        intent.putExtra("nombre pedido", nombre);
        intent.putExtra("Origen", pedido.getOrigen());
        intent.putExtra("Destino", pedido.getDestino());
        intent.putExtra("Estado", pedido.getEstado());
        intent.putExtra("Precio", pedido.getPrecio());
        startActivity(intent);

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == CODE_AGREGAR_PEDIDO && resultCode == 1) {
            actualizarLista();
        }

        if (requestCode == 102 && resultCode == -1) {

        }
    }
}


