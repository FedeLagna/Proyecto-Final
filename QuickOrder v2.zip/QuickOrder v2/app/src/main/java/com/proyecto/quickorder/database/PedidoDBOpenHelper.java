package com.proyecto.quickorder.database;


import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class PedidoDBOpenHelper extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "pedidos.db";
    public static final int VERSION = 1;
    public static final String TAG = "OpenHelper";

    public String CREATE_TABLE_PEDIDO = "CREATE TABLE pedido (id INTEGER PRIMARY KEY autoincrement, " +
            "nombre TEXT," +
            "Origen TEXT," +
            "Destino TEXT," +
            "Estado TEXT," +
            "Precio TEXT,";

    public String INSERT_PEDIDO1 = "INSERT INTO pedido (nombre, Orden, Destino, Estado, Precio) VALUES ('ZAPATILLAS', 'PROVIDENCIA 255', " +
            "'MERCED 753', 'EN PROCESO', '$2000')";

    public String INSERT_PEDIDO2 = "INSERT INTO pedido (nombre, Orden, Destino, Estado, Precio) VALUES ('IPHONE 11', 'HOLANDA 100', " +
            "'APOQUINDO 3885', 'EN PROCESO', '$5000')";

    public PedidoDBOpenHelper(Context context) { super(context, DATABASE_NAME, null, VERSION);  }

        @Override
public void onCreate (SQLiteDatabase db) {

    db.execSQL(CREATE_TABLE_PEDIDO);
        Log.i(TAG, "Se creo la tabla pedido");

        db.execSQL(INSERT_PEDIDO1);
        Log.i(TAG, "Se insero el pedido 1");

        db.execSQL(INSERT_PEDIDO2);
        Log.i(TAG, "Se insero el pedido 2");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1){

    }
}