package com.proyecto.quickorder.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.proyecto.quickorder.library.Pedido;

import java.util.ArrayList;
import java.util.List;

public class PedidoDataSource {

    public static final String TAG = "db";
    SQLiteOpenHelper dbhelper;
    SQLiteDatabase database;

    public PedidoDataSource(Context context ) {
        dbhelper = new PedidoDBOpenHelper(context);
    }

    public void openDB(){
        database = dbhelper.getWritableDatabase();
        Log.i(TAG, "openDB");

    }

    public void closeDB(){
        dbhelper.close();
        Log.i(TAG, "closeDB");
    }

    public List<Pedido> obtenerPedido(){

        List<Pedido> pedidos = new ArrayList<>();

        String query = "SELECT * FROM contacto";
        Cursor cursor = database.rawQuery(query, null);

        Log.i(TAG, "Filas Retomadas: "+ cursor.getCount());

        if (cursor.getCount()>0){
            while (cursor.moveToNext()){
                Pedido pedido =new Pedido();
                pedido.setId(cursor.getLong(cursor.getColumnIndex("id")));
                pedido.setNombre(cursor.getString(cursor.getColumnIndex("nombre")));
                pedido.setOrigen(cursor.getString(cursor.getColumnIndex("Origen")));
                pedido.setDestino(cursor.getString(cursor.getColumnIndex("Destino")));
                pedido.setEstado(cursor.getString(cursor.getColumnIndex("Estado")));
                pedido.setPrecio(cursor.getString(cursor.getColumnIndex("Precio")));

                pedidos.add(pedido);
            }
        }

        return pedidos;
    }

    public Pedido insertarPedido (Pedido pedido){
        ContentValues valores = new ContentValues();
        valores.put("nombre",pedido.getNombre());
        valores.put("Origen",pedido.getOrigen());
        valores.put("Destino",pedido.getDestino());
        valores.put("Estado",pedido.getEstado());
        valores.put("Precio",pedido.getPrecio());

        long insertid = database.insert("pedido", null, valores);
        pedido.setId(insertid);

        return pedido;
    }

    public boolean eliminarPedido(long id){

        String where = "id = "+id;
        int result  = database.delete("pedido", where, null);
        Log.i(TAG,"Se eliminó pedido con ID: "+id);
        return (result ==1);
    }


}
