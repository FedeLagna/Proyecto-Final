package com.proyecto.quickorder.library;

public class Pedido {

    long id;
    String nombre;
    String origen;
    String destino;
    String estado;
    String precio;

    public String getNombre() {return nombre;}

    public void setNombre(String nombre) {this.nombre = nombre;}

    public  String getOrigen() {return origen;}

    public void setOrigen(String origen) {this.origen = this.origen;}

    public  String getDestino() {return destino;}

    public void setDestino(String destino) {this.destino = this.destino;}

    public String getEstado() {return estado;}

    public void setEstado(String estado) {this.estado = this.estado; }

    public String getPrecio() {return precio;}

    public void setPrecio(String precio) {this.precio = this.precio;}

    public long getId() {return id; }
    public void setId(long id) {this.id = id;}

    @Override
    public String toString() {return nombre + ' '+ origen +' '+ destino +' '+ estado +' '+ precio;}


}
