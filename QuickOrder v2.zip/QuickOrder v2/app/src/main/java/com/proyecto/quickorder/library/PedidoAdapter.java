package com.proyecto.quickorder.library;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.proyecto.quickorder.R;

import java.util.List;

public class PedidoAdapter extends ArrayAdapter<Pedido> {

    Context context;
    List<Pedido> objects;

    public PedidoAdapter(Context context, int resource, List<Pedido> objects){
        super(context, resource, objects);

        this.context = context;
        this.objects = objects;
    }

    @NonNull
    @Override

    public View getView(int position, @Nullable View covertView, @NonNull ViewGroup parent){
        Pedido pedido = objects.get(position);

        LayoutInflater inflater = LayoutInflater.from(getContext());
        View view = inflater.inflate(R.layout.pedido_item, null);

        TextView tvNombrePedido = view.findViewById(R.id.tvNombrePedido);
        tvNombrePedido.setText(pedido.toString());

        return view;
    }


}
